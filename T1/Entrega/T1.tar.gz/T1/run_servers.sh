#!/bin/bash

# Script shell para correr los servers

echo "Running servers..."

../servers/server_echo2.py & ../servers/server_echo4.py & ../servers/server_echo5.py