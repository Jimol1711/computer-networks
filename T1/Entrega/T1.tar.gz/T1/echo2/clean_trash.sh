#!/bin/bash

rm -f trash/*